package com.jsp.theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.theatre_management_system.dto.Address;
import com.jsp.theatre_management_system.dto.Screen;
import com.jsp.theatre_management_system.dto.Theatre;
import com.jsp.theatre_management_system.service.TheatreService;
import com.jsp.theatre_management_system.util.ResponseStructure;

@RestController
public class TheatreController {
	@Autowired
	TheatreService theatreService;

	@PostMapping("/saveTheatre")
	public ResponseEntity<ResponseStructure<Theatre>> saveTheatre(@RequestBody Theatre theatre) {
		return theatreService.saveTheatre(theatre);
	}

	@GetMapping("/fetchTheatreById")
	public ResponseEntity<ResponseStructure<Theatre>> fetchTheatreById(@RequestParam int id) {
		return theatreService.fetchTheatreById(id);
	}

	@DeleteMapping("/deleteTheatre")
	public ResponseEntity<ResponseStructure<Theatre>> deleteTheatre(@RequestParam int id) {
		return theatreService.deleteTheatre(id);
	}

	@PutMapping("/updateTheatre")
	public ResponseEntity<ResponseStructure<Theatre>> updateTheatre(@RequestParam int id,
			@RequestBody Theatre theatre) {
		return theatreService.updateTheatre(id, theatre);
	}

	@PutMapping("/addExistingAddressToExistingTheatre")
	public ResponseEntity<ResponseStructure<Theatre>> addExistingAddressToExistingTheatre(@RequestParam int addressId,
			@RequestParam int theatreId) {
		return theatreService.addExistingAddressToExistingTheatre(addressId, theatreId);
	}

	@PostMapping("/addNewAddressToExistingTheatre")
	public ResponseEntity<ResponseStructure<Theatre>> addNewAddressToExistingTheatre(@RequestParam int theatreId,
			@RequestParam Address address) {
		return theatreService.addNewAddressToExistingTheatre(theatreId, address);
	}

	@PutMapping("/addExistingScreensToExistingTheatre")
	public ResponseEntity<ResponseStructure<Theatre>> addExistingScreensToExistingTheatre(@RequestParam int screenId,
			@RequestParam int theatreId) {
		return theatreService.addExistingScreensToExistingTheatre(screenId, theatreId);
	}

	@PostMapping("/addNewScreenToExistingTheatre")
	public ResponseEntity<ResponseStructure<Theatre>> addNewScreenToExistingTheatre(@RequestParam int theatreId,
			@RequestBody Screen screen) {
		return theatreService.addNewScreenToExistingTheatre(theatreId, screen);
	}
}
