package com.jsp.theatre_management_system.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.theatre_management_system.dto.Viewers;

public interface ViewersRepo extends JpaRepository<Viewers, Integer>{

}
