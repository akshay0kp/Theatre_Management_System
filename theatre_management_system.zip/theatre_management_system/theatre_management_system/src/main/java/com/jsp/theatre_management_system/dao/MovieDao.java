package com.jsp.theatre_management_system.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.theatre_management_system.dto.Movie;
import com.jsp.theatre_management_system.dto.Ticket;
import com.jsp.theatre_management_system.dto.Viewers;
import com.jsp.theatre_management_system.repo.MovieRepo;

@Repository
public class MovieDao {
	@Autowired
	MovieRepo movieRepo;
	@Autowired
	ViewersDao viewersDao;
	@Autowired
	TicketDao ticketDao;

	public Movie saveMovie(Movie movie) {
		return movieRepo.save(movie);
	}

	public Movie fetchMovieById(int id) {
		Optional<Movie> movie = movieRepo.findById(id);
		if (movie.isPresent()) {
			return movie.get();
		} else {
			return null;
		}
	}

	public Movie deleteMovie(int id) {
		Movie movie = fetchMovieById(id);
		movieRepo.delete(movie);
		return movie;
	}

	public Movie updateMovie(int id, Movie movie) {
		movie.setMovieId(id);
		return movieRepo.save(movie);
	}

	public Movie addExistingViewersToExistingMovie(int viewersId, int movieId) {
		Movie movie = fetchMovieById(movieId);
		Viewers viewers = viewersDao.fetchViewersById(viewersId);
		movie.getViewers().add(viewers);
		return saveMovie(movie);
	}

	public Movie addNewViewersToExistingMovie(int movieId, Viewers viewers) {
		Movie movie = fetchMovieById(movieId);
		movie.getViewers().add(viewers);
		return saveMovie(movie);
	}

	public Movie addExistingTicketToExistingMovie(int ticketId, int movieId) {
		Movie movie = fetchMovieById(movieId);
		Ticket ticket = ticketDao.fetchTicketById(ticketId);
		movie.getTickets().add(ticket);
		return saveMovie(movie);
	}

	public Movie addNewTicketToExistingMovie(int movieId, Ticket ticket) {
		Movie movie = fetchMovieById(movieId);
		movie.getTickets().add(ticket);
		return saveMovie(movie);
	}
}
