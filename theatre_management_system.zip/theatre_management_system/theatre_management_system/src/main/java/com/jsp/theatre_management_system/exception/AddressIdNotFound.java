package com.jsp.theatre_management_system.exception;

@SuppressWarnings("serial")
public class AddressIdNotFound extends RuntimeException {
	private String message = "AddressId Is Not found In DB .";

	public String getMessage() {
		return message;
	}
}
