package com.jsp.theatre_management_system.dto;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Movie {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int movieId;
	private String movieName;
	private double movieBudget;
	private String movieDirector;
	private String movieHero;
	private String movieHeroine;
	@OneToMany(cascade = CascadeType.ALL)
	private List<Viewers> viewers;
	@OneToMany(cascade = CascadeType.ALL)
	private List<Ticket> tickets;

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public double getMovieBudget() {
		return movieBudget;
	}

	public void setMovieBudget(double movieBudget) {
		this.movieBudget = movieBudget;
	}

	public String getMovieDirector() {
		return movieDirector;
	}

	public void setMovieDirector(String movieDirector) {
		this.movieDirector = movieDirector;
	}

	public String getMovieHero() {
		return movieHero;
	}

	public void setMovieHero(String movieHero) {
		this.movieHero = movieHero;
	}

	public String getMovieHeroine() {
		return movieHeroine;
	}

	public void setMovieHeroine(String movieHeroine) {
		this.movieHeroine = movieHeroine;
	}

	public List<Viewers> getViewers() {
		return viewers;
	}

	public void setViewers(List<Viewers> viewers) {
		this.viewers = viewers;
	}

	public List<Ticket> getTickets() {
		return tickets;
	}

	public void setTickets(List<Ticket> tickets) {
		this.tickets = tickets;
	}
	/*
	 * {"movieName":"", "movieBudget":, "movieDirector":"", "movieHero":"",
	 * "movieHeroine":""}
	 */
}
