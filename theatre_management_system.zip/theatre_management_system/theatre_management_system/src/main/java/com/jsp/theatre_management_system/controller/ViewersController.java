package com.jsp.theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.theatre_management_system.dto.Viewers;
import com.jsp.theatre_management_system.service.ViewersService;
import com.jsp.theatre_management_system.util.ResponseStructure;

@RestController
public class ViewersController {
	@Autowired
	ViewersService viewersService;

	@PostMapping("/saveViewers")
	public ResponseEntity<ResponseStructure<Viewers>> saveViewers(@RequestBody Viewers viewers) {
		return viewersService.saveViewers(viewers);
	}

	@GetMapping("/fetchViewersById")
	public ResponseEntity<ResponseStructure<Viewers>> fetchViewersById(@RequestParam int id) {
		return viewersService.fetchViewersById(id);
	}

	@DeleteMapping("/deleteViewers")
	public ResponseEntity<ResponseStructure<Viewers>> deleteViewers(@RequestParam int id) {
		return viewersService.deleteViewers(id);
	}

	@PutMapping("/updateViewers")
	public ResponseEntity<ResponseStructure<Viewers>> updateViewers(@RequestParam int id,
			@RequestBody Viewers viewers) {
		return viewersService.updateViewers(id, viewers);
	}
}
