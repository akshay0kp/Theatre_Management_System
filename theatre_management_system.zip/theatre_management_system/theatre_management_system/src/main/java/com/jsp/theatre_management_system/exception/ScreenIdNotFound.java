package com.jsp.theatre_management_system.exception;

@SuppressWarnings("serial")
public class ScreenIdNotFound extends RuntimeException {
	private String message = "ScreenId Is Not Found In Db.";

	public String getMessage() {
		return message;
	}
}
