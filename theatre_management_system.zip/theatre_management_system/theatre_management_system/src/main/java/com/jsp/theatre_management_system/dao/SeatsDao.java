package com.jsp.theatre_management_system.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.theatre_management_system.dto.Seats;
import com.jsp.theatre_management_system.repo.SeatsRepo;

@Repository
public class SeatsDao {
	@Autowired
	SeatsRepo seatsRepo;

	public Seats saveSeats(Seats seats) {
		return seatsRepo.save(seats);
	}

	public Seats fetchSeatsById(int id) {
		Optional<Seats> seats = seatsRepo.findById(id);
		if (seats.isPresent()) {
			return seatsRepo.findById(id).get();
		} else {
			return null;
		}
	}

	public Seats deleteSeats(int id) {
		Seats seats = fetchSeatsById(id);
		seatsRepo.delete(seats);
		return seats;
	}

	public Seats updateSeats(int id, Seats seats) {
		seats.setSeatId(id);
		return seatsRepo.save(seats);
	}
}
