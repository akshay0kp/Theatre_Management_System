package com.jsp.theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jsp.theatre_management_system.dao.SeatsDao;
import com.jsp.theatre_management_system.dto.Seats;
import com.jsp.theatre_management_system.exception.SeatsIdNotFound;
import com.jsp.theatre_management_system.util.ResponseStructure;

@Service
public class SeatsService {
	@Autowired
	SeatsDao seatsDao;

	public ResponseEntity<ResponseStructure<Seats>> saveSeats(Seats seats) {
		ResponseStructure<Seats> responseStructure = new ResponseStructure<Seats>();
		responseStructure.setStatus(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Inserted Seats into DB .");
		responseStructure.setData(seatsDao.saveSeats(seats));
		return new ResponseEntity<ResponseStructure<Seats>>(responseStructure, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Seats>> fetchSeatsById(int id) {
		Seats seats = seatsDao.fetchSeatsById(id);
		if (seats != null) {
			ResponseStructure<Seats> responseStructure = new ResponseStructure<Seats>();
			responseStructure.setStatus(HttpStatus.FOUND.value());
			responseStructure.setMessage("Successfully Fetched Seats from DB .");
			responseStructure.setData(seatsDao.fetchSeatsById(id));
			return new ResponseEntity<ResponseStructure<Seats>>(responseStructure, HttpStatus.FOUND);
		} else {
			throw new SeatsIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Seats>> deleteSeats(int id) {
		Seats seats = seatsDao.fetchSeatsById(id);
		if (seats != null) {
			ResponseStructure<Seats> responseStructure = new ResponseStructure<Seats>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Deleted Seats from DB .");
			responseStructure.setData(seatsDao.deleteSeats(id));
			return new ResponseEntity<ResponseStructure<Seats>>(responseStructure, HttpStatus.OK);
		} else {
			throw new SeatsIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Seats>> updateSeats(int id, Seats seats) {
		Seats seatss = seatsDao.fetchSeatsById(id);
		if (seatss != null) {
			ResponseStructure<Seats> responseStructure = new ResponseStructure<Seats>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Updated Seats from DB .");
			responseStructure.setData(seatsDao.updateSeats(id, seats));
			return new ResponseEntity<ResponseStructure<Seats>>(responseStructure, HttpStatus.OK);
		} else {
			throw new SeatsIdNotFound();
		}
	}
}
