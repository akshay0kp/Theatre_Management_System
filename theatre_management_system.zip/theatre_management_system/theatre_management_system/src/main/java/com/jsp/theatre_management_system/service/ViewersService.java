package com.jsp.theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jsp.theatre_management_system.dao.ViewersDao;
import com.jsp.theatre_management_system.dto.Viewers;
import com.jsp.theatre_management_system.exception.ViewersIdNotFound;
import com.jsp.theatre_management_system.util.ResponseStructure;

@Service
public class ViewersService {
	@Autowired
	ViewersDao viewersDao;

	public ResponseEntity<ResponseStructure<Viewers>> saveViewers(Viewers viewers) {
		ResponseStructure<Viewers> responseStructure = new ResponseStructure<Viewers>();
		responseStructure.setStatus(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Inserted Viewers into DB .");
		responseStructure.setData(viewersDao.saveViewers(viewers));
		return new ResponseEntity<ResponseStructure<Viewers>>(responseStructure, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Viewers>> fetchViewersById(int id) {
		Viewers viewers = viewersDao.fetchViewersById(id);
		if (viewers != null) {
			ResponseStructure<Viewers> responseStructure = new ResponseStructure<Viewers>();
			responseStructure.setStatus(HttpStatus.FOUND.value());
			responseStructure.setMessage("Successfully Fetched Viewers from DB .");
			responseStructure.setData(viewersDao.fetchViewersById(id));
			return new ResponseEntity<ResponseStructure<Viewers>>(responseStructure, HttpStatus.FOUND);
		} else {
			throw new ViewersIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Viewers>> deleteViewers(int id) {
		Viewers viewers = viewersDao.fetchViewersById(id);
		if (viewers != null) {
			ResponseStructure<Viewers> responseStructure = new ResponseStructure<Viewers>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Deleted Viewers from DB .");
			responseStructure.setData(viewersDao.deleteViewers(id));
			return new ResponseEntity<ResponseStructure<Viewers>>(responseStructure, HttpStatus.OK);
		} else {
			throw new ViewersIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Viewers>> updateViewers(int id, Viewers viewers) {
		Viewers viewerss = viewersDao.fetchViewersById(id);
		if (viewerss != null) {
			ResponseStructure<Viewers> responseStructure = new ResponseStructure<Viewers>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Upadted Viewers into DB .");
			responseStructure.setData(viewersDao.saveViewers(viewers));
			return new ResponseEntity<ResponseStructure<Viewers>>(responseStructure, HttpStatus.OK);
		} else {
			throw new ViewersIdNotFound();
		}
	}
}
