package com.jsp.theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.theatre_management_system.dto.Seats;
import com.jsp.theatre_management_system.service.SeatsService;
import com.jsp.theatre_management_system.util.ResponseStructure;

@RestController
public class SeatsController {
	@Autowired
	SeatsService seatsService;

	@PostMapping("/saveSeats")
	public ResponseEntity<ResponseStructure<Seats>> saveSeats(@RequestBody Seats seats) {
		return seatsService.saveSeats(seats);
	}

	@GetMapping("/fetchSeatsById")
	public ResponseEntity<ResponseStructure<Seats>> fetchSeatsById(@RequestParam int id) {
		return seatsService.fetchSeatsById(id);
	}

	@DeleteMapping("/deleteSeats")
	public ResponseEntity<ResponseStructure<Seats>> deleteSeats(@RequestParam int id) {
		return seatsService.deleteSeats(id);
	}

	@PutMapping("/updateSeats")
	public ResponseEntity<ResponseStructure<Seats>> updateSeats(@RequestParam int id, @RequestBody Seats seats) {
		return seatsService.updateSeats(id, seats);
	}
}
