package com.jsp.theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.jsp.theatre_management_system.dao.TheatreDao;
import com.jsp.theatre_management_system.dto.Address;
import com.jsp.theatre_management_system.dto.Screen;
import com.jsp.theatre_management_system.dto.Theatre;
import com.jsp.theatre_management_system.exception.TheatreIdNotFound;
import com.jsp.theatre_management_system.util.ResponseStructure;

@Service
public class TheatreService {
	@Autowired
	TheatreDao theatreDao;

	public ResponseEntity<ResponseStructure<Theatre>> saveTheatre(Theatre theatre) {
		ResponseStructure<Theatre> responseStructure = new ResponseStructure<Theatre>();
		responseStructure.setStatus(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Inserted Shows into DB .");
		responseStructure.setData(theatreDao.saveTheatre(theatre));
		return new ResponseEntity<ResponseStructure<Theatre>>(responseStructure, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Theatre>> fetchTheatreById(int id) {
		Theatre theatre = theatreDao.fetchTheatreById(id);
		if (theatre != null) {
			ResponseStructure<Theatre> responseStructure = new ResponseStructure<Theatre>();
			responseStructure.setStatus(HttpStatus.FOUND.value());
			responseStructure.setMessage("Successfully Fetched Shows from DB .");
			responseStructure.setData(theatreDao.fetchTheatreById(id));
			return new ResponseEntity<ResponseStructure<Theatre>>(responseStructure, HttpStatus.FOUND);
		} else {
			throw new TheatreIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Theatre>> deleteTheatre(int id) {
		Theatre theatre = theatreDao.fetchTheatreById(id);
		if (theatre != null) {
			ResponseStructure<Theatre> responseStructure = new ResponseStructure<Theatre>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Deleted Shows from DB .");
			responseStructure.setData(theatreDao.deleteTheatre(id));
			return new ResponseEntity<ResponseStructure<Theatre>>(responseStructure, HttpStatus.OK);
		} else {
			throw new TheatreIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Theatre>> updateTheatre(int id, Theatre theatre) {
		Theatre theatree = theatreDao.fetchTheatreById(id);
		if (theatree != null) {
			ResponseStructure<Theatre> responseStructure = new ResponseStructure<Theatre>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Updated Shows into DB .");
			responseStructure.setData(theatreDao.updateTheatre(id, theatre));
			return new ResponseEntity<ResponseStructure<Theatre>>(responseStructure, HttpStatus.OK);
		} else {
			throw new TheatreIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Theatre>> addExistingAddressToExistingTheatre(@RequestParam int addressId,
			@RequestParam int theatreId) {
		ResponseStructure<Theatre> responseStructure = new ResponseStructure<Theatre>();
		responseStructure.setStatus(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Mapped ExistingAddressToExistingTheatre.");
		responseStructure.setData(theatreDao.addExistingAddressToExistingTheatre(addressId, theatreId));
		return new ResponseEntity<ResponseStructure<Theatre>>(responseStructure, HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Theatre>> addExistingScreensToExistingTheatre(int screenId, int theatreId) {
		ResponseStructure<Theatre> responseStructure = new ResponseStructure<Theatre>();
		responseStructure.setStatus(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Mapped ExistingScreensToExistingTheatre.");
		responseStructure.setData(theatreDao.addExistingScreensToExistingTheatre(screenId, theatreId));
		return new ResponseEntity<ResponseStructure<Theatre>>(responseStructure, HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Theatre>> addNewScreenToExistingTheatre(int theatreId, Screen screen) {
		Theatre theatre = theatreDao.fetchTheatreById(theatreId);
		if (theatre != null) {
			ResponseStructure<Theatre> responseStructure = new ResponseStructure<Theatre>();
			responseStructure.setStatus(HttpStatus.CREATED.value());
			responseStructure.setMessage("Successfully Mapped NewScreenToExistingTheatre.");
			responseStructure.setData(theatreDao.addNewScreenToExistingTheatre(theatreId, screen));
			return new ResponseEntity<ResponseStructure<Theatre>>(responseStructure, HttpStatus.CREATED);
		} else {
			throw new TheatreIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Theatre>> addNewAddressToExistingTheatre(int theatreId, Address address) {
		Theatre theatre = theatreDao.fetchTheatreById(theatreId);
		if (theatre != null) {
			ResponseStructure<Theatre> responseStructure = new ResponseStructure<Theatre>();
			responseStructure.setStatus(HttpStatus.CREATED.value());
			responseStructure.setMessage("Successfully Mapped NewAddressToExistingTheatre.");
			responseStructure.setData(theatreDao.addNewAddressToExistingTheatre(theatreId, address));
			return new ResponseEntity<ResponseStructure<Theatre>>(responseStructure, HttpStatus.CREATED);
		} else {
			throw new TheatreIdNotFound();
		}
	}
}
