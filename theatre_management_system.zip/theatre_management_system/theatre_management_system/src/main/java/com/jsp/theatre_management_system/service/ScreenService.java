package com.jsp.theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.jsp.theatre_management_system.dao.ScreenDao;
import com.jsp.theatre_management_system.dto.Movie;
import com.jsp.theatre_management_system.dto.Screen;
import com.jsp.theatre_management_system.dto.Shows;
import com.jsp.theatre_management_system.exception.ScreenIdNotFound;
import com.jsp.theatre_management_system.util.ResponseStructure;

@Service
public class ScreenService {
	@Autowired
	ScreenDao screenDao;

	public ResponseEntity<ResponseStructure<Screen>> saveScreen(Screen screen) {
		ResponseStructure<Screen> responseStructure = new ResponseStructure<Screen>();
		responseStructure.setStatus(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Inserted Screen into DB");
		responseStructure.setData(screenDao.saveScreen(screen));
		return new ResponseEntity<ResponseStructure<Screen>>(responseStructure, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Screen>> fetchScreenById(int id) {
		Screen screen = screenDao.fetchScreenById(id);
		if (screen != null) {
			ResponseStructure<Screen> responseStructure = new ResponseStructure<Screen>();
			responseStructure.setStatus(HttpStatus.FOUND.value());
			responseStructure.setMessage("Successfully Fetched Screen from DB");
			responseStructure.setData(screenDao.fetchScreenById(id));
			return new ResponseEntity<ResponseStructure<Screen>>(responseStructure, HttpStatus.FOUND);
		} else {
			throw new ScreenIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Screen>> deleteScreen(int id) {
		Screen screen = screenDao.fetchScreenById(id);
		if (screen != null) {
			ResponseStructure<Screen> responseStructure = new ResponseStructure<Screen>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Deleted Screen from DB");
			responseStructure.setData(screenDao.deleteScreen(id));
			return new ResponseEntity<ResponseStructure<Screen>>(responseStructure, HttpStatus.OK);
		} else {
			throw new ScreenIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Screen>> updateScreen(int id, Screen screen) {
		Screen screeen = screenDao.fetchScreenById(id);
		if (screeen != null) {
			ResponseStructure<Screen> responseStructure = new ResponseStructure<Screen>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Updated Screen into DB");
			responseStructure.setData(screenDao.updateScreen(id, screen));
			return new ResponseEntity<ResponseStructure<Screen>>(responseStructure, HttpStatus.OK);
		} else {
			throw new ScreenIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Screen>> addExistingMovieToExistingScreen(@RequestParam int movieId,
			@RequestParam int screenId) {
		ResponseStructure<Screen> responseStructure = new ResponseStructure<Screen>();
		responseStructure.setStatus(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Mapped ExistingMovieToExistingScreen");
		responseStructure.setData(screenDao.addExistingMovieToExistingScreen(movieId, screenId));
		return new ResponseEntity<ResponseStructure<Screen>>(responseStructure, HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Screen>> addNewMovieToExistingScreen(int screenId, Movie movie) {
		Screen screen = screenDao.fetchScreenById(screenId);
		if (screen != null) {
			ResponseStructure<Screen> responseStructure = new ResponseStructure<Screen>();
			responseStructure.setStatus(HttpStatus.CREATED.value());
			responseStructure.setMessage("Successfully Mapped NewMovieToExistingScreen");
			responseStructure.setData(screenDao.addNewMovieToExistingScreen(screenId, movie));
			return new ResponseEntity<ResponseStructure<Screen>>(responseStructure, HttpStatus.CREATED);
		} else {
			throw new ScreenIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Screen>> addExistingShowsToExistingScreen(int showsId, int screenId) {
		ResponseStructure<Screen> responseStructure = new ResponseStructure<Screen>();
		responseStructure.setStatus(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Mapped ExistingShowsToExistingScreen");
		responseStructure.setData(screenDao.addExistingShowsToExistingScreen(showsId, screenId));
		return new ResponseEntity<ResponseStructure<Screen>>(responseStructure, HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Screen>> addNewShowsToExistingScreen(int screenId, Shows shows) {
		Screen screen = screenDao.fetchScreenById(screenId);
		if (screen != null) {
			ResponseStructure<Screen> responseStructure = new ResponseStructure<Screen>();
			responseStructure.setStatus(HttpStatus.CREATED.value());
			responseStructure.setMessage("Successfully Mapped NewShowsToExistingScreen .");
			responseStructure.setData(screenDao.addNewShowsToExistingScreen(screenId, shows));
			return new ResponseEntity<ResponseStructure<Screen>>(responseStructure, HttpStatus.CREATED);
		} else {
			throw new ScreenIdNotFound();
		}
	}
}
