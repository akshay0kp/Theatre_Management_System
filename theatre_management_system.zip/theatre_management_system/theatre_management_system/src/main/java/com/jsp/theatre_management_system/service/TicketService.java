package com.jsp.theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jsp.theatre_management_system.dao.TicketDao;
import com.jsp.theatre_management_system.dto.Seats;
import com.jsp.theatre_management_system.dto.Ticket;
import com.jsp.theatre_management_system.exception.TicketIdNotFound;
import com.jsp.theatre_management_system.util.ResponseStructure;

@Service
public class TicketService {
	@Autowired
	TicketDao ticketDao;

	public ResponseEntity<ResponseStructure<Ticket>> saveTicket(Ticket ticket) {
		ResponseStructure<Ticket> responseStructure = new ResponseStructure<Ticket>();
		responseStructure.setStatus(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Inserted Ticket into DB .");
		responseStructure.setData(ticketDao.saveTicket(ticket));
		return new ResponseEntity<ResponseStructure<Ticket>>(responseStructure, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Ticket>> fetchTicketById(int id) {
		Ticket ticket = ticketDao.fetchTicketById(id);
		if (ticket != null) {
			ResponseStructure<Ticket> responseStructure = new ResponseStructure<Ticket>();
			responseStructure.setStatus(HttpStatus.FOUND.value());
			responseStructure.setMessage("Successfully Fetched Ticket from DB .");
			responseStructure.setData(ticketDao.fetchTicketById(id));
			return new ResponseEntity<ResponseStructure<Ticket>>(responseStructure, HttpStatus.FOUND);
		} else {
			throw new TicketIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Ticket>> deleteTicket(int id) {
		Ticket ticket = ticketDao.fetchTicketById(id);
		if (ticket != null) {
			ResponseStructure<Ticket> responseStructure = new ResponseStructure<Ticket>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Deleted Ticket from DB .");
			responseStructure.setData(ticketDao.deleteTicket(id));
			return new ResponseEntity<ResponseStructure<Ticket>>(responseStructure, HttpStatus.OK);
		} else {
			throw new TicketIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Ticket>> updateTicket(int id, Ticket ticket) {
		Ticket tickett = ticketDao.fetchTicketById(id);
		if (tickett != null) {
			ResponseStructure<Ticket> responseStructure = new ResponseStructure<Ticket>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Updated Ticket into DB .");
			responseStructure.setData(ticketDao.updateTicket(id, ticket));
			return new ResponseEntity<ResponseStructure<Ticket>>(responseStructure, HttpStatus.OK);
		} else {
			throw new TicketIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Ticket>> addExistingSeatToExistingTicket(int seatId, int ticketId) {
		ResponseStructure<Ticket> responseStructure = new ResponseStructure<Ticket>();
		responseStructure.setStatus(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Mapped ExistingSeatToExistingTicket");
		responseStructure.setData(ticketDao.addExistingSeatToExistingTicket(seatId, ticketId));
		return new ResponseEntity<ResponseStructure<Ticket>>(responseStructure, HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Ticket>> addNewSeatToExistingTicket(int ticketId, Seats seats) {
		Ticket ticket = ticketDao.fetchTicketById(ticketId);
		if (ticket != null) {
			ResponseStructure<Ticket> responseStructure = new ResponseStructure<Ticket>();
			responseStructure.setStatus(HttpStatus.CREATED.value());
			responseStructure.setMessage("Successfully Mapped NewSeatToExistingTicket");
			responseStructure.setData(ticketDao.addNewSeatToExistingTicket(ticketId, seats));
			return new ResponseEntity<ResponseStructure<Ticket>>(responseStructure, HttpStatus.CREATED);
		} else {
			throw new TicketIdNotFound();
		}
	}
}
