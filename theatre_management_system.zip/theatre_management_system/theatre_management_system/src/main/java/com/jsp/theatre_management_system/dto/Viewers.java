package com.jsp.theatre_management_system.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Viewers {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int viewerId;
	private String viewerName;
	private Long viewerPhone;
	private String viewerAddress;
	private String viewerEmail;
	private String viewerGender;

	public int getViewerId() {
		return viewerId;
	}

	public void setViewerId(int viewerId) {
		this.viewerId = viewerId;
	}

	public String getViewerName() {
		return viewerName;
	}

	public void setViewerName(String viewerName) {
		this.viewerName = viewerName;
	}

	public Long getViewerPhone() {
		return viewerPhone;
	}

	public void setViewerPhone(Long viewerPhone) {
		this.viewerPhone = viewerPhone;
	}

	public String getViewerAddress() {
		return viewerAddress;
	}

	public void setViewerAddress(String viewerAddress) {
		this.viewerAddress = viewerAddress;
	}

	public String getViewerEmail() {
		return viewerEmail;
	}

	public void setViewerEmail(String viewerEmail) {
		this.viewerEmail = viewerEmail;
	}

	public String getViewerGender() {
		return viewerGender;
	}

	public void setViewerGender(String viewerGender) {
		this.viewerGender = viewerGender;
	}
}
