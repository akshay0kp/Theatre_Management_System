package com.jsp.theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jsp.theatre_management_system.dao.MovieDao;
import com.jsp.theatre_management_system.dto.Movie;
import com.jsp.theatre_management_system.dto.Ticket;
import com.jsp.theatre_management_system.dto.Viewers;
import com.jsp.theatre_management_system.exception.MovieIdNotFound;
import com.jsp.theatre_management_system.util.ResponseStructure;

@Service
public class MovieService {
	@Autowired
	MovieDao movieDao;

	public ResponseEntity<ResponseStructure<Movie>> saveMovie(Movie movie) {
		ResponseStructure<Movie> responseStructure = new ResponseStructure<Movie>();
		responseStructure.setStatus(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Inserted Movie into DB");
		responseStructure.setData(movieDao.saveMovie(movie));
		return new ResponseEntity<ResponseStructure<Movie>>(responseStructure, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Movie>> fetchMovieById(int id) {
		Movie movie = movieDao.fetchMovieById(id);
		if (movie != null) {
			ResponseStructure<Movie> responseStructure = new ResponseStructure<Movie>();
			responseStructure.setStatus(HttpStatus.FOUND.value());
			responseStructure.setMessage("Successfully Fetched Movie from DB");
			responseStructure.setData(movieDao.fetchMovieById(id));
			return new ResponseEntity<ResponseStructure<Movie>>(responseStructure, HttpStatus.FOUND);
		} else {
			throw new MovieIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Movie>> deleteMovie(int id) {
		Movie movie = movieDao.fetchMovieById(id);
		if (movie != null) {
			ResponseStructure<Movie> responseStructure = new ResponseStructure<Movie>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Deleted Movie from DB");
			responseStructure.setData(movieDao.deleteMovie(id));
			return new ResponseEntity<ResponseStructure<Movie>>(responseStructure, HttpStatus.OK);
		} else {
			throw new MovieIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Movie>> updateMovie(int id, Movie movie) {
		Movie moviee = movieDao.fetchMovieById(id);
		if (moviee != null) {
			ResponseStructure<Movie> responseStructure = new ResponseStructure<Movie>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Updated Movie into DB");
			responseStructure.setData(movieDao.updateMovie(id, movie));
			return new ResponseEntity<ResponseStructure<Movie>>(responseStructure, HttpStatus.OK);
		} else {
			throw new MovieIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Movie>> addExistingViewersToExistingMovie(int viewersId, int movieId) {
		ResponseStructure<Movie> responseStructure = new ResponseStructure<Movie>();
		responseStructure.setStatus(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Mapped ExistingViewersToExistingMovie .");
		responseStructure.setData(movieDao.addExistingViewersToExistingMovie(viewersId, movieId));
		return new ResponseEntity<ResponseStructure<Movie>>(responseStructure, HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Movie>> addNewViewersToExistingMovie(int movieId, Viewers viewers) {
		Movie movie = movieDao.fetchMovieById(movieId);
		if (movie != null) {
			ResponseStructure<Movie> responseStructure = new ResponseStructure<Movie>();
			responseStructure.setStatus(HttpStatus.CREATED.value());
			responseStructure.setMessage("Successfully Mapped NewViewersToExistingMovie .");
			responseStructure.setData(movieDao.addNewViewersToExistingMovie(movieId, viewers));
			return new ResponseEntity<ResponseStructure<Movie>>(responseStructure, HttpStatus.CREATED);
		} else {
			throw new MovieIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Movie>> addExistingTicketToExistingMovie(int ticketId, int movieId) {
		ResponseStructure<Movie> responseStructure = new ResponseStructure<Movie>();
		responseStructure.setStatus(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Mapped ExistingTicketToExistingMovie .");
		responseStructure.setData(movieDao.addExistingTicketToExistingMovie(ticketId, movieId));
		return new ResponseEntity<ResponseStructure<Movie>>(responseStructure, HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Movie>> addNewTicketToExistingMovie(int movieId, Ticket ticket) {
		Movie movie = movieDao.fetchMovieById(movieId);
		if (movie != null) {
			ResponseStructure<Movie> responseStructure = new ResponseStructure<Movie>();
			responseStructure.setStatus(HttpStatus.CREATED.value());
			responseStructure.setMessage("Successfully Mapped NewTicketToExistingMovie .");
			responseStructure.setData(movieDao.addNewTicketToExistingMovie(movieId, ticket));
			return new ResponseEntity<ResponseStructure<Movie>>(responseStructure, HttpStatus.CREATED);
		} else {
			throw new MovieIdNotFound();
		}
	}
}
