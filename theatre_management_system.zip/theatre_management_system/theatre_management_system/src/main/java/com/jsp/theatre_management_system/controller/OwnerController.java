package com.jsp.theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.theatre_management_system.dto.Owner;
import com.jsp.theatre_management_system.dto.Theatre;
import com.jsp.theatre_management_system.service.OwnerService;
import com.jsp.theatre_management_system.util.ResponseStructure;

@RestController
public class OwnerController {
	@Autowired
	OwnerService ownerService;

	@PostMapping("/saveOwner")
	public ResponseEntity<ResponseStructure<Owner>> saveOwner(@RequestBody Owner owner) {
		return ownerService.saveOwner(owner);
	}

	@GetMapping("/fetchOwnerById")
	public ResponseEntity<ResponseStructure<Owner>> fetchOwnerById(@RequestParam int id) {
		return ownerService.fetchOwnerById(id);
	}

	@DeleteMapping("/deleteOwner")
	public ResponseEntity<ResponseStructure<Owner>> deleteOwner(@RequestParam int id) {
		return ownerService.deleteOwner(id);
	}

	@PutMapping("/updateOwner")
	public ResponseEntity<ResponseStructure<Owner>> updateOwner(@RequestParam int oldId, @RequestBody Owner newOwner) {
		return ownerService.updateOwner(oldId, newOwner);
	}

	@PutMapping("/addExistingTheatreToExistingOwner")
	public ResponseEntity<ResponseStructure<Owner>> addExistingTheatreToExistingOwner(@RequestParam int theatreId,
			@RequestParam int ownerId) {
		return ownerService.addExistingTheatreToExistingOwner(theatreId, ownerId);
	}

	@PostMapping("/addNewTheatreToExistingOwner")
	public ResponseEntity<ResponseStructure<Owner>> addNewTheatreToExistingOwner(@RequestParam int ownerId,
			@RequestBody Theatre theatre) {
		return ownerService.addNewTheatreToExistingOwner(ownerId, theatre);
	}
}
