package com.jsp.theatre_management_system.exception;

@SuppressWarnings("serial")
public class TheatreIdNotFound extends RuntimeException {
	private String message = "TheatreId Is Not Found In DB.";

	public String getMessage() {
		return message;
	}
}
