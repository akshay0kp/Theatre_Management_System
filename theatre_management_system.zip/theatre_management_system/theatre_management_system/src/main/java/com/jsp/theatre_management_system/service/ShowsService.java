package com.jsp.theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jsp.theatre_management_system.dao.ShowsDao;
import com.jsp.theatre_management_system.dto.Shows;
import com.jsp.theatre_management_system.exception.ShowsIdNotFound;
import com.jsp.theatre_management_system.util.ResponseStructure;

@Service
public class ShowsService {
	@Autowired
	ShowsDao showsDao;

	public ResponseEntity<ResponseStructure<Shows>> saveShows(Shows shows) {
		ResponseStructure<Shows> responseStructure = new ResponseStructure<Shows>();
		responseStructure.setStatus(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Inserted Shows into DB .");
		responseStructure.setData(showsDao.saveShows(shows));
		return new ResponseEntity<ResponseStructure<Shows>>(responseStructure, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Shows>> fetchShowsById(int id) {
		Shows shows = showsDao.fetchShowsById(id);
		if (shows != null) {
			ResponseStructure<Shows> responseStructure = new ResponseStructure<Shows>();
			responseStructure.setStatus(HttpStatus.FOUND.value());
			responseStructure.setMessage("Successfully Fetched Shows from DB .");
			responseStructure.setData(showsDao.fetchShowsById(id));
			return new ResponseEntity<ResponseStructure<Shows>>(responseStructure, HttpStatus.FOUND);
		} else {
			throw new ShowsIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Shows>> deleteShows(int id) {
		Shows shows = showsDao.fetchShowsById(id);
		if (shows != null) {
			ResponseStructure<Shows> responseStructure = new ResponseStructure<Shows>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Deleted Shows from DB .");
			responseStructure.setData(showsDao.deleteShows(id));
			return new ResponseEntity<ResponseStructure<Shows>>(responseStructure, HttpStatus.OK);
		} else {
			throw new ShowsIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Shows>> updateShows(int id, Shows shows) {
		Shows showss = showsDao.fetchShowsById(id);
		if (showss != null) {
			ResponseStructure<Shows> responseStructure = new ResponseStructure<Shows>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Updated Shows into DB .");
			responseStructure.setData(showsDao.updateShows(id, shows));
			return new ResponseEntity<ResponseStructure<Shows>>(responseStructure, HttpStatus.OK);
		} else {
			throw new ShowsIdNotFound();
		}
	}
}
