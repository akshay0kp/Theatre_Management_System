package com.jsp.theatre_management_system.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.jsp.theatre_management_system.dto.Address;
import com.jsp.theatre_management_system.dto.Screen;
import com.jsp.theatre_management_system.dto.Theatre;
import com.jsp.theatre_management_system.repo.TheatreRepo;

@Repository
public class TheatreDao {
	@Autowired
	TheatreRepo theatreRepo;

	@Autowired
	AddressDao addressDao;

	@Autowired
	ScreenDao screenDao;

	public Theatre saveTheatre(Theatre theatre) {
		return theatreRepo.save(theatre);
	}

	public Theatre fetchTheatreById(int id) {
		Optional<Theatre> theatre = theatreRepo.findById(id);
		if (theatre.isPresent()) {
			return theatreRepo.findById(id).get();
		} else {
			return null;
		}
	}

	public Theatre deleteTheatre(int id) {
		Theatre theatre = fetchTheatreById(id);
		theatreRepo.delete(theatre);
		return theatre;
	}

	public Theatre updateTheatre(int id, Theatre theatre) {
		theatre.setTheatreId(id);
		return theatreRepo.save(theatre);
	}

	public Theatre addExistingAddressToExistingTheatre(@RequestParam int addressId, @RequestParam int theatreId) {
		Address address = addressDao.fetchAddressById(addressId);
		Theatre theatre = fetchTheatreById(theatreId);
		theatre.setAddress(address);
		return saveTheatre(theatre);
	}

	public Theatre addNewAddressToExistingTheatre(int theatreId, Address address) {
		Theatre theatre = fetchTheatreById(theatreId);
		theatre.setAddress(address);
		return saveTheatre(theatre);
	}

	public Theatre addExistingScreensToExistingTheatre(int screenId, int theatreId) {
		Theatre theatre = fetchTheatreById(theatreId);
		Screen screen = screenDao.fetchScreenById(screenId);
//		List<Screen> screens = theatre.getScreens();
//		screens.add(screen);
		theatre.getScreens().add(screen);
		return saveTheatre(theatre);
	}

	public Theatre addNewScreenToExistingTheatre(int theatreId, Screen screen) {
		Theatre theatre = fetchTheatreById(theatreId);
		theatre.getScreens().add(screen);
		return saveTheatre(theatre);
	}
}
