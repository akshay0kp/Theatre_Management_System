package com.jsp.theatre_management_system.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.theatre_management_system.dto.Seats;
import com.jsp.theatre_management_system.dto.Ticket;
import com.jsp.theatre_management_system.repo.TicketRepo;

@Repository
public class TicketDao {
	@Autowired
	TicketRepo ticketRepo;
	@Autowired
	SeatsDao seatsDao;

	public Ticket saveTicket(Ticket ticket) {
		return ticketRepo.save(ticket);
	}

	public Ticket fetchTicketById(int id) {
		Optional<Ticket> ticket = ticketRepo.findById(id);
		if (ticket.isPresent()) {
			return ticketRepo.findById(id).get();
		} else {
			return null;
		}
	}

	public Ticket deleteTicket(int id) {
		Ticket ticket = fetchTicketById(id);
		ticketRepo.delete(ticket);
		return ticket;
	}

	public Ticket updateTicket(int id, Ticket ticket) {
		ticket.setTicketId(id);
		return ticketRepo.save(ticket);
	}

	public Ticket addExistingSeatToExistingTicket(int seatId, int ticketId) {
		Ticket ticket = fetchTicketById(ticketId);
		Seats seats = seatsDao.fetchSeatsById(seatId);
		ticket.setSeats(seats);
		return saveTicket(ticket);
	}

	public Ticket addNewSeatToExistingTicket(int ticketId, Seats seats) {
		Ticket ticket = fetchTicketById(ticketId);
		ticket.setSeats(seats);
		return saveTicket(ticket);
	}
}
