package com.jsp.theatre_management_system.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.jsp.theatre_management_system.dto.Movie;
import com.jsp.theatre_management_system.dto.Screen;
import com.jsp.theatre_management_system.dto.Shows;
import com.jsp.theatre_management_system.repo.ScreenRepo;

@Repository
public class ScreenDao {
	@Autowired
	ScreenRepo screenRepo;

	@Autowired
	MovieDao movieDao;
	@Autowired
	ShowsDao showsDao;

	public Screen saveScreen(Screen screen) {
		return screenRepo.save(screen);
	}

	public Screen fetchScreenById(int id) {
		Optional<Screen> screen = screenRepo.findById(id);
		if (screen.isPresent()) {
			return screen.get();
		} else {
			return null;
		}
	}

	public Screen deleteScreen(int id) {
		Screen screen = fetchScreenById(id);
		screenRepo.delete(screen);
		return screen;
	}

	public Screen updateScreen(int id, Screen screen) {
		screen.setScreenId(id);
		return screenRepo.save(screen);
	}

	public Screen addExistingMovieToExistingScreen(@RequestParam int movieId, @RequestParam int screenId) {
		Movie movie = movieDao.fetchMovieById(movieId);
		Screen screen = fetchScreenById(screenId);
		screen.setMovie(movie);
		return saveScreen(screen);
	}

	public Screen addNewMovieToExistingScreen(int screenId, Movie movie) {
		Screen screen = fetchScreenById(screenId);
		screen.setMovie(movie);
		return saveScreen(screen);
	}

	public Screen addExistingShowsToExistingScreen(int showsId, int screenId) {
		Screen screen = fetchScreenById(screenId);
		Shows shows = showsDao.fetchShowsById(showsId);
		screen.getShows().add(shows);
		return saveScreen(screen);
	}

	public Screen addNewShowsToExistingScreen(int screenId, Shows shows) {
		Screen screen = fetchScreenById(screenId);
		screen.getShows().add(shows);
		return saveScreen(screen);
	}
}
