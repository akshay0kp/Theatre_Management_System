package com.jsp.theatre_management_system.exception;

@SuppressWarnings("serial")
public class TicketIdNotFound extends RuntimeException {
	private String message = "TicketId Is Not Found In DB.";

	public String getMessage() {
		return message;
	}
}
