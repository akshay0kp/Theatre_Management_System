package com.jsp.theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.theatre_management_system.dto.Seats;
import com.jsp.theatre_management_system.dto.Ticket;
import com.jsp.theatre_management_system.service.TicketService;
import com.jsp.theatre_management_system.util.ResponseStructure;

@RestController
public class TicketController {
	@Autowired
	TicketService ticketService;

	@PostMapping("/saveTicket")
	public ResponseEntity<ResponseStructure<Ticket>> saveTicket(@RequestBody Ticket ticket) {
		return ticketService.saveTicket(ticket);
	}

	@GetMapping("/fetchTicketById")
	public ResponseEntity<ResponseStructure<Ticket>> fetchTicketById(@RequestParam int id) {
		return ticketService.fetchTicketById(id);
	}

	@DeleteMapping("/deleteTicket")
	public ResponseEntity<ResponseStructure<Ticket>> deleteTicket(@RequestParam int id) {
		return ticketService.deleteTicket(id);
	}

	@PutMapping("/updateTicket")
	public ResponseEntity<ResponseStructure<Ticket>> updateTicket(@RequestParam int id, @RequestBody Ticket ticket) {
		return ticketService.updateTicket(id, ticket);
	}

	@PutMapping("/addExistingSeatToExistingTicket")
	public ResponseEntity<ResponseStructure<Ticket>> addExistingSeatToExistingTicket(@RequestParam int seatId,
			@RequestParam int ticketId) {
		return ticketService.addExistingSeatToExistingTicket(seatId, ticketId);
	}

	@PostMapping("/addNewSeatToExistingTicket")
	public ResponseEntity<ResponseStructure<Ticket>> addNewSeatToExistingTicket(@RequestParam int ticketId,
			@RequestBody Seats seats) {
		return ticketService.addNewSeatToExistingTicket(ticketId, seats);
	}
}
