package com.jsp.theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jsp.theatre_management_system.dao.OwnerDao;
import com.jsp.theatre_management_system.dao.TheatreDao;
import com.jsp.theatre_management_system.dto.Owner;
import com.jsp.theatre_management_system.dto.Theatre;
import com.jsp.theatre_management_system.exception.OwnerIdNotFound;
import com.jsp.theatre_management_system.exception.TheatreIdNotFound;
import com.jsp.theatre_management_system.util.ResponseStructure;

@Service
public class OwnerService {
	@Autowired
	OwnerDao ownerDao;
	@Autowired
	TheatreDao theatreDao;

	public ResponseEntity<ResponseStructure<Owner>> saveOwner(Owner owner) {
		ResponseStructure<Owner> responseStructure = new ResponseStructure<Owner>();
		responseStructure.setStatus(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Inserted Owner into DB");
		responseStructure.setData(ownerDao.saveOwner(owner));
		return new ResponseEntity<ResponseStructure<Owner>>(responseStructure, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Owner>> fetchOwnerById(int id) {
		Owner owner = ownerDao.fetchOwnerById(id);
		if (owner != null) {
			ResponseStructure<Owner> responseStructure = new ResponseStructure<Owner>();
			responseStructure.setStatus(HttpStatus.FOUND.value());
			responseStructure.setMessage("Successfully Fetched Owner from DB");
			responseStructure.setData(ownerDao.fetchOwnerById(id));
			return new ResponseEntity<ResponseStructure<Owner>>(responseStructure, HttpStatus.FOUND);
		} else {
			throw new OwnerIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Owner>> deleteOwner(int id) {
		Owner owner = ownerDao.fetchOwnerById(id);
		if (owner != null) {
			ResponseStructure<Owner> responseStructure = new ResponseStructure<Owner>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Deleted Owner from DB");
			responseStructure.setData(ownerDao.deleteOwner(id));
			return new ResponseEntity<ResponseStructure<Owner>>(responseStructure, HttpStatus.OK);
		} else {
			throw new OwnerIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Owner>> updateOwner(int oldId, Owner newOwner) {
		Owner owner = ownerDao.fetchOwnerById(oldId);
		if (owner != null) {
			ResponseStructure<Owner> responseStructure = new ResponseStructure<Owner>();
			responseStructure.setStatus(HttpStatus.OK.value());
			responseStructure.setMessage("Successfully Updated Owner into DB");
			responseStructure.setData(ownerDao.updateOwner(oldId, newOwner));
			return new ResponseEntity<ResponseStructure<Owner>>(responseStructure, HttpStatus.OK);
		} else {
			throw new OwnerIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Owner>> addExistingTheatreToExistingOwner(int theatreId, int ownerId) {
		Owner owner = ownerDao.fetchOwnerById(ownerId);
		if (owner != null) {
			Theatre theatre = theatreDao.fetchTheatreById(theatreId);
			if (theatre != null) {
				ResponseStructure<Owner> responseStructure = new ResponseStructure<Owner>();
				responseStructure.setStatus(HttpStatus.OK.value());
				responseStructure.setMessage("Successfully Mapped ExistingTheatreToExistingOwner");
				responseStructure.setData(ownerDao.adddExistingTheatreToExistingOwner(theatreId, ownerId));
				return new ResponseEntity<ResponseStructure<Owner>>(responseStructure, HttpStatus.OK);
			} else {
				throw new TheatreIdNotFound();
			}
		} else {
			throw new OwnerIdNotFound();
		}
	}

	public ResponseEntity<ResponseStructure<Owner>> addNewTheatreToExistingOwner(int ownerId, Theatre theatre) {
		Owner owner = ownerDao.fetchOwnerById(ownerId);
		if (owner != null) {
			ResponseStructure<Owner> responseStructure = new ResponseStructure<Owner>();
			responseStructure.setStatus(HttpStatus.CREATED.value());
			responseStructure.setMessage("Successfully Mapped NewTheatreToExistingOwner");
			responseStructure.setData(ownerDao.addNewTheatreToExistingOwner(ownerId, theatre));
			return new ResponseEntity<ResponseStructure<Owner>>(responseStructure, HttpStatus.CREATED);
		} else {
			throw new OwnerIdNotFound();
		}
	}
}
