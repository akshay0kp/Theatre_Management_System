package com.jsp.theatre_management_system.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.theatre_management_system.dto.Viewers;
import com.jsp.theatre_management_system.repo.ViewersRepo;

@Repository
public class ViewersDao {
	@Autowired
	ViewersRepo viewersRepo;

	public Viewers saveViewers(Viewers viewers) {
		return viewersRepo.save(viewers);
	}

	public Viewers fetchViewersById(int id) {
		Optional<Viewers> viewers = viewersRepo.findById(id);
		if (viewers.isPresent()) {
			return viewersRepo.findById(id).get();
		} else {
			return null;
		}
	}

	public Viewers deleteViewers(int id) {
		Viewers viewers = fetchViewersById(id);
		viewersRepo.delete(viewers);
		return viewers;
	}

	public Viewers updateViewers(int id, Viewers viewers) {
		viewers.setViewerId(id);
		return viewersRepo.save(viewers);
	}
}
