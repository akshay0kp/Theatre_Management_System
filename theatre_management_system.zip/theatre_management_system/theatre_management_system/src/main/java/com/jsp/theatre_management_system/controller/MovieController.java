package com.jsp.theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.theatre_management_system.dto.Movie;
import com.jsp.theatre_management_system.dto.Ticket;
import com.jsp.theatre_management_system.dto.Viewers;
import com.jsp.theatre_management_system.service.MovieService;
import com.jsp.theatre_management_system.util.ResponseStructure;

@RestController
public class MovieController {
	@Autowired
	MovieService movieService;

	@PostMapping("/saveMovie")
	public ResponseEntity<ResponseStructure<Movie>> saveMovie(@RequestBody Movie movie) {
		return movieService.saveMovie(movie);
	}

	@GetMapping("/fetchMovieById")
	public ResponseEntity<ResponseStructure<Movie>> fetchMovieById(@RequestParam int id) {
		return movieService.fetchMovieById(id);
	}

	@DeleteMapping("/deleteMovie")
	public ResponseEntity<ResponseStructure<Movie>> deleteMovie(@RequestParam int id) {
		return movieService.deleteMovie(id);
	}

	@PutMapping("/updateMovie")
	public ResponseEntity<ResponseStructure<Movie>> updateMovie(@RequestParam int id, @RequestBody Movie movie) {
		return movieService.updateMovie(id, movie);
	}

	@PutMapping("/addExistingViewersToExistingMovie")
	public ResponseEntity<ResponseStructure<Movie>> addExistingViewersToExistingMovie(@RequestParam int viewersId,
			@RequestParam int movieId) {
		return movieService.addExistingViewersToExistingMovie(viewersId, movieId);
	}

	@PostMapping("/addNewViewersToExistingMovie")
	public ResponseEntity<ResponseStructure<Movie>> addNewViewersToExistingMovie(@RequestParam int movieId,
			@RequestBody Viewers viewers) {
		return movieService.addNewViewersToExistingMovie(movieId, viewers);
	}

	@PutMapping("/addExistingTicketToExistingMovie")
	public ResponseEntity<ResponseStructure<Movie>> addExistingTicketToExistingMovie(@RequestParam int ticketId,
			@RequestParam int movieId) {
		return movieService.addExistingTicketToExistingMovie(ticketId, movieId);
	}

	@PostMapping("/addNewTicketToExistingMovie")
	public ResponseEntity<ResponseStructure<Movie>> addNewTicketToExistingMovie(@RequestParam int movieId,
			@RequestBody Ticket ticket) {
		return movieService.addNewTicketToExistingMovie(movieId, ticket);
	}
}
