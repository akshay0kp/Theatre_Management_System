package com.jsp.theatre_management_system.exception;

@SuppressWarnings("serial")
public class ViewersIdNotFound extends RuntimeException {
	private String message = "ViewersId Is Not Found In DB.";

	public String getMessage() {
		return message;
	}
}
