package com.jsp.theatre_management_system.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.theatre_management_system.dto.Owner;
import com.jsp.theatre_management_system.dto.Theatre;
import com.jsp.theatre_management_system.repo.OwnerRepo;

@Repository
public class OwnerDao {
	@Autowired
	OwnerRepo ownerRepo;

	@Autowired
	TheatreDao theatreDao;

	public Owner saveOwner(Owner owner) {
		return ownerRepo.save(owner);
	}

	public Owner fetchOwnerById(int id) {
		Optional<Owner> owner = ownerRepo.findById(id);
		if (owner.isPresent()) {
			return owner.get();
		} else {
			return null;
		}
	}

	public Owner deleteOwner(int id) {
		Owner owner = fetchOwnerById(id);
		ownerRepo.delete(owner);
		return owner;
	}

	public Owner updateOwner(int oldId, Owner newOwner) {
		newOwner.setOwnerId(oldId);
		return ownerRepo.save(newOwner);
	}

	public Owner addExistingTheatreToExistingOwner(int theatreId, int ownerId) {
		Theatre theatre = theatreDao.fetchTheatreById(theatreId);
		Owner owner = fetchOwnerById(ownerId);
		owner.setTheatre(theatre);
		return saveOwner(owner);
	}

	public Owner adddExistingTheatreToExistingOwner(int theatreId, int ownerId) {
		Owner owner = fetchOwnerById(ownerId);
		Theatre theatre = theatreDao.fetchTheatreById(theatreId);
		owner.getTheatres().add(theatre);
		return saveOwner(owner);
	}

	public Owner addNewTheatreToExistingOwner(int ownerId, Theatre theatre) {
		Owner owner = fetchOwnerById(ownerId);
		owner.getTheatres().add(theatre);
		return owner;
	}
}
