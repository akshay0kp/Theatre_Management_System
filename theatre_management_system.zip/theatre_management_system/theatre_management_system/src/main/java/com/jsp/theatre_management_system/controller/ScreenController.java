package com.jsp.theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.theatre_management_system.dto.Movie;
import com.jsp.theatre_management_system.dto.Screen;
import com.jsp.theatre_management_system.dto.Shows;
import com.jsp.theatre_management_system.service.ScreenService;
import com.jsp.theatre_management_system.util.ResponseStructure;

@RestController
public class ScreenController {
	@Autowired
	ScreenService screenService;

	@PostMapping("/saveScreen")
	public ResponseEntity<ResponseStructure<Screen>> saveScreen(@RequestBody Screen screen) {
		return screenService.saveScreen(screen);
	}

	@GetMapping("/fetchScreenById")
	public ResponseEntity<ResponseStructure<Screen>> fetchScreenById(@RequestParam int id) {
		return screenService.fetchScreenById(id);
	}

	@DeleteMapping("/deleteScreen")
	public ResponseEntity<ResponseStructure<Screen>> deleteScreen(@RequestParam int id) {
		return screenService.deleteScreen(id);
	}

	@PutMapping("/updateScreen")
	public ResponseEntity<ResponseStructure<Screen>> updateScreen(@RequestParam int id, @RequestBody Screen screen) {
		return screenService.updateScreen(id, screen);
	}

	@PutMapping("/addExistingMovieToExistingScreen")
	public ResponseEntity<ResponseStructure<Screen>> addExistingMovieToExistingScreen(@RequestParam int movieId,
			@RequestParam int screenId) {
		return screenService.addExistingMovieToExistingScreen(movieId, screenId);
	}

	@PostMapping("/addNewMovieToExistingScreen")
	public ResponseEntity<ResponseStructure<Screen>> addNewMovieToExistingScreen(@RequestParam int screenId,
			@RequestBody Movie movie) {
		return screenService.addNewMovieToExistingScreen(screenId, movie);
	}

	@PutMapping("/addExistingShowsToExistingScreen")
	public ResponseEntity<ResponseStructure<Screen>> addExistingShowsToExistingScreen(@RequestParam int showsId,
			@RequestParam int screenId) {
		return screenService.addExistingShowsToExistingScreen(showsId, screenId);
	}

	@PostMapping("/addNewShowsToExistingScreen")
	public ResponseEntity<ResponseStructure<Screen>> addNewShowsToExistingScreen(@RequestParam int screenId,
			@RequestBody Shows shows) {
		return screenService.addNewShowsToExistingScreen(screenId, shows);
	}
}
