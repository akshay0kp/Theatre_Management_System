package com.jsp.theatre_management_system.exception;

@SuppressWarnings("serial")
public class MovieIdNotFound extends RuntimeException {
	private String message = "MovieId Is Not Found In DB .";

	public String getMessage() {
		return message;
	}
}
