package com.jsp.theatre_management_system.exception;

@SuppressWarnings("serial")
public class ShowsIdNotFound extends RuntimeException {
	private String message = "ShowsId Is Not Found In DB.";

	public String getMessage() {
		return message;
	}
}
