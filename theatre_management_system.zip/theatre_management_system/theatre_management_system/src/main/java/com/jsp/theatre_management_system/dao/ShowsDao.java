package com.jsp.theatre_management_system.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.theatre_management_system.dto.Shows;
import com.jsp.theatre_management_system.repo.ShowsRepo;

@Repository
public class ShowsDao {
	@Autowired
	ShowsRepo showsRepo;

	public Shows saveShows(Shows shows) {
		return showsRepo.save(shows);
	}

	public Shows fetchShowsById(int id) {
		Optional<Shows> shows = showsRepo.findById(id);
		if (shows.isPresent()) {
			return showsRepo.findById(id).get();
		} else {
			return null;
		}
	}

	public Shows deleteShows(int id) {
		Shows shows = fetchShowsById(id);
		showsRepo.delete(shows);
		return shows;
	}

	public Shows updateShows(int id, Shows shows) {
		shows.setShowId(id);
		return showsRepo.save(shows);
	}
}
