package com.jsp.theatre_management_system.exception;

@SuppressWarnings("serial")
public class SeatsIdNotFound extends RuntimeException {
	private String message = "SeatsID Is Not Found In Db.";

	public String getMessage() {
		return message;
	}
}
